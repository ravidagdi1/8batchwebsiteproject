const mongoose=require('mongoose')

const serverSchema=mongoose.Schema({
    img:{
        required:true,
        type:String
    },
    name:{
        required:true,
        type:String
    },
    desc:{
        required:true,
        type:String,
    },
    mdesc:{
        required:true,
        type:String
    },
    createDate:{
        required:true,
        type:Date,
        default:new Date()
    },
    status:{
        type:String,
        default:'Unpublished',
        required:true
    }
})
module.exports=mongoose.model('service',serverSchema)