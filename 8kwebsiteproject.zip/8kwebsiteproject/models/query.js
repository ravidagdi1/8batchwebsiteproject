const mongoose=require('mongoose')



let querySchema=mongoose.Schema({
    query:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    postedDate:{
        type:Date,
        default:new Date(),
        required:true
    },
    status:{
        type:String,
        required:true,
        default:'Need to Reply'
    }
})

module.exports=mongoose.model('query',querySchema)