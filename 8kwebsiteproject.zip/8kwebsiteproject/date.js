let a=new Date()
console.log(a)

