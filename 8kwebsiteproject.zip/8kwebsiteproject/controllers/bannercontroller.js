const bannerTable=require('../models/banner')
const fs=require('fs')

exports.bannermanagement=async(req,res)=>{
    const username=req.session.loginname
    const data=await bannerTable.find()
    res.render('admin/bannermanagement.ejs',{username,data})
}


exports.bannerform=(req,res)=>{
    let message=''
    const username=req.session.loginname
    res.render('admin/bannerform.ejs',{username,message})
}

exports.newbanner=(req,res)=>{
    const username=req.session.loginname
    let message=''
    try{
    const{title,desc,mdesc}=req.body
    if(!title || !desc || !mdesc) {
        throw new Error("All fields are compulsory fileds , Please fill!!")
    }else if(!req.file){
        throw new Error("Banner Image is required!!!.Please upload Image")
    }
    const filename=req.file.filename
    const newbanner=new bannerTable({title:title,desc:desc,mdesc:mdesc,img:filename})
    newbanner.save()
    //console.log(newbanner)
    message='Successfully Banner has been Added!!!'
   
    }catch(error){
        message=error.message

    }
    res.render('admin/bannerform.ejs',{username,message})
}

exports.statusupdate=async(req,res)=>{
    let cureentStatus=req.params.status
    let id=req.params.id
    let updateStatus=null
    if(cureentStatus=='Unpublished'){
        updateStatus='Published'
    }else{
        updateStatus='Unpublished'
    }

   await bannerTable.findByIdAndUpdate(id,{status:updateStatus})
    res.redirect('/admin/bannermanagement')

}

exports.delete=async(req,res)=>{
    const id=req.params.id
    const img=req.params.imgname
    await bannerTable.findByIdAndDelete(id)
    fs.unlinkSync(`./public/upload/${img}`)
    res.redirect('/admin/bannermanagement')
}

exports.moredetails=async(req,res)=>{
   const data= await bannerTable.findOne({status:'Published'})
    res.render('banner.ejs',{data})
}

exports.bannerupdateform=async(req,res)=>{
    const username=req.session.loginname
    const id=req.params.id
    const data=await bannerTable.findById(id)
    //console.log(data)
    res.render('admin/bannerupdateform.ejs',{username,data})
}

exports.bannerupdate=async(req,res)=>{
   const id= req.params.id
    const{title}=req.body
    if(req.file){
    const filename=req.file.filename
    await bannerTable.findByIdAndUpdate(id,{title:title,img:filename})

    }else{
        await bannerTable.findByIdAndUpdate(id,{title:title})
 
    }
    res.redirect('/admin/bannermanagement')
}