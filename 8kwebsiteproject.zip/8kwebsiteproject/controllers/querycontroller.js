const queryTable=require('../models/query')
const nodemailer=require('nodemailer')
require('dotenv').config()

exports.addquery=(req,res)=>{
    const{email,query}=req.body
   const newquery= new queryTable({query:query,email:email})
   newquery.save()
   res.render('message.ejs')
}

exports.bannerdata=async(req,res)=>{
    const message=req.params.mess
    const username=req.session.loginname
   const data= await queryTable.find()
    res.render('admin/query.ejs',{username,data,message})
}

exports.queryform=(req, res) => {
    let message=''
    const username = req.session.loginname
    const email=req.params.email
    const query=req.params.query
    res.render('admin/queryform.ejs', { username,email,query,message })
}


exports.sendemail=async(req, res) => {
    let message=''
    const username = req.session.loginname
    const email=req.params.email
    const query=req.params.query
    const id=req.params.id
    const { emailto, emailfrom, sub, body } = req.body
    const transporter= nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        secure: false, // Use `true` for port 465, `false` for all other ports
        auth: {
            user:process.env.EMAILUSERNAME,
            pass:process.env.emailpassword,
        },
        })
        //console.log("connected to smtp server!!")
        await transporter.sendMail({
            from:emailfrom, // sender address
            to:emailto, // list of receivers
            subject:sub, // Subject line
            text:body, // plain text body
            //html: "<b>Hello world?</b>", // html body
          });
         // console.log("sent email!!!")
          await queryTable.findByIdAndUpdate(id,{status:'Reply has been sent'})
         message='Email has been sent!!'
        res.render('admin/queryform.ejs', { username,email,query,message})
        
}

exports.delete=async(req,res)=>{
    const id=req.params.id
    await queryTable.findByIdAndDelete(id)
    res.redirect('/admin/query/Successsfull Query Has been deleted')
   
}