const serviceTable = require('../models/service')


exports.servicemanagement = async(req, res) => {
    let message=''
    try{
    var username = req.session.loginname
    var data=await serviceTable.find()
    var trecord=await serviceTable.find().count()
    var precord=await serviceTable.find({status:'Published'}).count()
    var urecord=await serviceTable.find({status:'Unpublished'}).count()

        if(data.length==0){
            throw new Error("No Record Found!!")
        }
    }catch(error){
        message=error.message
    }
    res.render('admin/servermanagement.ejs', { username, data,message,trecord,precord,urecord })

}

exports.serviceform = (req, res) => {
    let message=''
    const username = req.session.loginname
    res.render('admin/serviceform.ejs', { username,message })
}

exports.newservice = (req, res) => {
    let message=''
    const { sname, sdes, smdes } = req.body
   
    try {
        if (!sname) {
            throw new Error("Service Name should not be Blank!!")
        } else if (!sdes) {
            throw new Error("Service Description should not be Blank!!")

        } else if (!smdes) {
            throw new Error("Service More Deatils should not be Blank!!")
        }else if(!req.file){
            throw new Error("Service Image is compulsory.Please add!!")
        }
        const newservice = new serviceTable({ name: sname, desc: sdes, mdesc: smdes, img:req.file.filename })
        newservice.save()
        message='Successfully Service has been Added!!'
    } catch (error) {
        message=error.message
    }
    const username = req.session.loginname
    res.render('admin/serviceform.ejs',{username,message})
}

exports.servicestatusupdate=async(req,res)=>{
    const status=req.params.status
    const id=req.params.id
    let newstatus=null
    if(status=='Unpublished'){
        newstatus='Published'
    }else{
        newstatus='Unpublished'
 
    }
    
    await serviceTable.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/servermanagement')

}

exports.servericemoredetails=async(req,res)=>{
    const id=req.params.id
    const data=await serviceTable.findById(id)
        res.render('servicemoredetails.ejs',{data})
    }