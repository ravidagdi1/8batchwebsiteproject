const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const queryc=require('../controllers/querycontroller')



router.post('/',queryc.addquery)
router.get('/mbanner',bannerc.moredetails)
router.get('/servermordetails/:id',servicec.servericemoredetails)



module.exports=router