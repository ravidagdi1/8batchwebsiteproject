const router = require('express').Router()
const regc = require('../controllers/regcontroller')
const bannerc = require('../controllers/bannercontroller')
const servicec = require('../controllers/servicecontroller')
const queryc = require('../controllers/querycontroller')
const handlelogin = require('../midleware/sessioncheck')
const upload = require('../midleware/multer')
const nodemailer = require('nodemailer')



router.get('/', regc.loginform)
router.post('/', regc.logincheck)
router.get('/dashboard', handlelogin, (req, res) => {
    const username = req.session.loginname
    res.render('admin/dashboard.ejs', { username })
})

router.get('/logout', regc.logout)
router.get('/testimanagement', handlelogin, (req, res) => {
    const username = req.session.loginname
    res.render('admin/testi.ejs', { username })
})
//end of login urls

router.get('/newbanner', handlelogin, bannerc.bannerform).post('/newbanner', upload.single('img'), bannerc.newbanner).get('/bannermanagement', handlelogin, bannerc.bannermanagement)
router.get('/bannersupdate/:status/:id', bannerc.statusupdate).get('/bannerdelete/:id/:imgname', bannerc.delete)
router.get('/bannerupdate/:id', bannerc.bannerupdateform).post('/bannerupdate/:id', upload.single('img'), bannerc.bannerupdate)
//end banner routers

router.get('/servermanagement', handlelogin, servicec.servicemanagement)
router.get('/serviceadd', servicec.serviceform).post('/serviceadd', upload.single('img'), servicec.newservice)
router.get('/serviceschange/:status/:id', servicec.servicestatusupdate)
router.get('/query/:mess', queryc.bannerdata)
router.get('/queryform/:email/:query/:id',queryc.queryform).post('/queryform/:email/:query/:id',queryc.sendemail)
router.get('/querydelete/:id',queryc.delete)














module.exports = router