const router=require('express').Router()

const bannerTable=require('../models/banner')
const serviceTable=require('../models/service')

router.get('/',async(req,res)=>{
    const data=await bannerTable.findOne({status:'Published'})
    const servicedata=await serviceTable.find({status:'Published'})
    res.render('index.ejs',{data,servicedata})
})


module.exports=router