const express=require('express')//function
const app=express()//module
require('dotenv').config()
app.use(express.urlencoded({extended:false}))
require('./dbconnection/dbconfiguration')
const session=require('express-session')
const userRouter=require('./routers/userRouter')
const adminRouter=require('./routers/adminRouter')
const homeRouter=require('./routers/home')


app.use(session({
    secret:process.env.SkEY,
    resave:false,
    saveUninitialized:false,
    cookie:{maxAge:1*1000*60*60*24*365}
}))
app.use('/admin',adminRouter)
app.use('/users',userRouter)
app.use(homeRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(process.env.PORT,()=>{
    console.log(`server is running on port ${process.env.PORT}!!`)
})


